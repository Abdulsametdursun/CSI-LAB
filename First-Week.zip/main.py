print("First Name: Abdulsamet")
print("Last Name: Dursun")
#This program calculates something

'''Write want ever you want
asdfqpoeir
asdfav
vqroqner
'''

myFrirstVariable = "Woow"
print(myFrirstVariable)

first=12
second=20
third=30
print (first , second , third)

a="10"
b=3.612
print(10+3)
print(10+b)
print(type(b))

x=99
print(x)
x="New point"
print(x)

age="60"
print(age*3)

print(14//3)
print(14/3)
print(2**12)
print(2*12)
print(14%3)
print(2+3*4)

result=(2+3)*5
print(result)

a=3
b=4.5
print(a//b)

formula = 10 + 40 * 6.7 ,
3+6-2
print(formula)

print("a\n \"b\"")
print("a\n \t \"b\"")
print("a\n \t \"b\""+"c")
#print(a)