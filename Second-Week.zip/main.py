result1 = 3*0.75
result2 = 4*0.75
result3 = 5*0.75
print(result1, result2, result3)

#Make a short and easy :)
coEfficient=0.75
result1 = 3*coEfficient
result2 = 4*coEfficient
result3 = 5*coEfficient
print(result1, result2, result3)

MY_CONSTANT=12;
MY_CONSTANT=34;
print(MY_CONSTANT)
#Python is changing cod you assigned
PI_NUMBER=3.14
print(PI_NUMBER)
#DO NOT TOUCH code start with capital

if(True):
  print("HURRAAY")
#if(False) and Tab will not print
if(False):
  print("HURRAAY")
  print("WOOOW")
print("WOOOOOW")

weather ="cold"
if(weather=="cold"):
  print("Wear your jacket")

var1=40
var2=60
if(var1 > var2):
  print("Yee")
var1=66
var2=60
if(var1 > var2):
  print("Yes")
var1=66
var2=60
if(var1 != var2):
  print("Yas")
#!= means is not equal

if(True):
  print("Yes")
else:
  print("NO")
# check number=input("Enter a Number")

var1="apple"
var2="Apple"
if(var1==var2):
  print("OK")
var1="apple"
var2="apple"
if(var1==var2):
  print("Okay")
#Apple and apple is not equal 

number=45
if(number<20):
  print("Young")
elif(number<50):
  print("Midage")  
else:
  print("Old")
number=50
if(number<20):
  print("Young")
elif(number<50):
  print("Midage")  
else:
  print("Old")